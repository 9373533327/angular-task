import { ElementRef } from '@angular/core';
import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GlobalService } from '../global.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  @ViewChild('f', {static:true}) form: ElementRef;
  file:any;
  public user: any = {
    firstName: '',
  }
  constructor(private router: Router, private globalService: GlobalService) { }

  ngOnInit() {
  }
  gotoRegister(){
  }
onSubmit() {
 console.log(this.form);
 if(this.form['valid']) {
   // console.log(true)
   // console.log(this.user);
   this.user['file'] = this.file;
   this.globalService.setData(this.user);
   this.router.navigate(['/userprofile']);

   alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.user, null, 4));
 } else {
   // console.log(false);
 }

}
getFile(event: Event) {
 this.file = event.target['files'][0];
 var reader = new FileReader();
 reader.onloadend = () =>  {
   this.file = reader.result;
   // console.log(this.file);
   }
   reader.readAsDataURL(this.file);
}


}
