import { Component, OnInit } from '@angular/core';
import { GlobalService } from '../global.service';
import { ReplaySubject } from 'rxjs';
@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {
  file: any;
  userData: any;
  selectedFile:any;
  subject$ = new ReplaySubject(1);
  constructor(private globalService: GlobalService) { }

  ngOnInit() {
    this.globalService.getData().subscribe((response)=> {
      this.setData(response);
    });
  }
  setData(response) {
    this.userData = response;
  }
  readURL(input) {
    this.file = input.files[0];
  }
  // getFile(event: Event) {
  //   this.file = event.target['files'][0];
  //   var reader = new FileReader();
  //   reader.onloadend = () =>  {
  //     this.file = reader.result;
  //     // console.log(this.file);
  //     }
  //     reader.readAsDataURL(this.file);
  // }

  onFileSelect(event) {
    this.selectedFile = event.target['files'][0];
    var reader = new FileReader();
      reader.onloadend = () =>  {
        // this.selectedFile = reader.result;
        this.userData =Object.assign(this.userData ? this.userData : {}, {file: reader.result})
        // console.log(this.file);
      }
      console.log(this.selectedFile.name);
      reader.readAsDataURL(this.selectedFile);
  }
  getData(){
    return this.subject$.asObservable();
    
  }


}
