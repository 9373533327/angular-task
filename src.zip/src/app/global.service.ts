import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {
  subject$ = new ReplaySubject(1);
  constructor() { }
  setData(data) {
    this.subject$.next(data)
  }
  getData(){
    return this.subject$.asObservable();
  }
}
